<?php include("include/header.php"); ?>
<div class="wrap">
	<div class="main">
		<div class="section group">
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic16.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic17.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic18.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic19.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="section group">
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic20.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic21.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic22.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="col_1_of_4 span_1_of_4">
				<div class="image_grid portfolio_4col">
					<ul style="" id="list" class="portfolio_list da-thumbs">
						<li>
							<img src="images/pic23.jpg" alt="img">
							<article class="da-animate da-slideFromLeft" style="display: block;">
								<h3>Academia</h3>
								<span class="link_post"><a href="#"></a></span>
								<span class="zoom"><a href="#"></a></span>
							</article>
						</li>
					</ul>
				</div>
				<h3>Lorem Ipsum is simply dummy text </h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
				<div class="more1">
					<a href="#" class="button">Read More</a>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
<?php include("include/footer.php"); ?>