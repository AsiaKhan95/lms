<?php include("include/header.php"); ?>
<div class="wrap">
	<div class="main">
		<div class="about-top">
			<div class="lsidebar1 span_1_of_a offers_list">
				<h3>Testimonials</h3>
				<div class="testimonials">
					<h3>Finibus Bonorum Malorum<span><a href="#">http://demolink.org</a></span></h3>
					<p><span class="quotes"></span>consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.<span class="quotes-down"></span>
					</p>
				</div>
				<div class="testimonials">
					<h3>Finibus Bonorum Malorum<span><a href="#">http://demolink.org</a></span></h3>
					<p><span class="quotes"></span>consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat.<span class="quotes-down"></span>
					</p>
				</div>
				<div class="testimonials">
					<h3>Finibus Bonorum Malorum<span><a href="#">http://demolink.org</a></span></h3>
					<p><span class="quotes"></span>consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat.<span class="quotes-down"></span>
					</p>
				</div>
				<div class="testimonials">
					<h3>Finibus Bonorum Malorum<span><a href="#">http://demolink.org</a></span></h3>
					<p><span class="quotes"></span>consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat.<span class="quotes-down"></span>
					</p>
				</div>
			</div>
			<div class="cont1 span_2_of_a about_desc">
				<h2>About Us</h2>
				<p><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span>
				</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
				<div class="image group">
					<div class="grid images_3_of_1">
						<img src="images/pic13.jpg" alt="">
					</div>
					<div class="grid span_2_of_1">
						<h4>Lorem Ipsum is simply dummy text </h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat Duis aute irure.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.Ut wisi enim ad minim</p>
						<div class="more1">
							<a href="#" class="button">Read More</a>
						</div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="image group">
					<div class="grid images_3_of_1">
						<img src="images/pic14.jpg" alt="">
					</div>
					<div class="grid span_2_of_1">
						<h4>Lorem Ipsum is simply dummy text </h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat Duis aute irure.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.Ut wisi enim ad minim</p>
						<div class="more1">
							<a href="#" class="button">Read More</a>
						</div>
					</div>
					<div class="clear"></div>
				</div>
				<div class="image group">
					<div class="grid images_3_of_1">
						<img src="images/pic15.jpg" alt="">
					</div>
					<div class="grid span_2_of_1">
						<h4>Lorem Ipsum is simply dummy text </h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat Duis aute irure.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.Ut wisi enim ad minim</p>
						<div class="more1">
							<a href="#" class="button">Read More</a>
						</div>
					</div>
					<div class="clear"></div>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
<?php include("include/footer.php"); ?>