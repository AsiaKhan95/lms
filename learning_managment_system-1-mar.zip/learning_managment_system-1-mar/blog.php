<?php include("include/header.php"); ?>
<div class="wrap">
	<div class="main">
		<div class="page-not-found">
			<h1>404</h1>
		</div>
	</div>
</div>
<?php include("include/footer.php"); ?>