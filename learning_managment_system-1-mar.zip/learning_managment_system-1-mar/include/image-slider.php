<!--start-image-slider---->
		<div class="image-slider">
		<!-- Slideshow 1 -->
		  <ul class="rslides" id="slider1">
			  <li><img src="images/5.jpg" alt=""></li>
			<li><img src="images/t-pic4.jpg" alt=""></li>
		  </ul>
	    <!-- Slideshow 2 -->
	   </div>
	<!--End-image-slider---->