
<!DOCTYPE HTML>
<html>
<head>
	<title>
		<?php
		// set page title
		$title = $_SERVER['PHP_SELF'];
		$str = explode("/","$title");
		$title = end($str);
		if($title == "index.php"){
			echo "Home";
		}
		elseif($title == "about.php"){
			echo "About";
		}
		elseif($title == "gallery.php"){
			echo "Gallery";
		}
		elseif($title == "contact.php"){
			echo "Contact";
		}
		else{
		echo "Learning Managment System";
		}
		?>
		
		| Learninig Managment System
	</title>
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link href="//fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="css/responsiveslides.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/responsiveslides.min.js"></script>
	<script>
		// You can also use "$(window).load(function() {"
		$( function () {
			// Slideshow 1
			$( "#slider1" ).responsiveSlides( {
				maxwidth: 2500,
				speed: 600
			} );
		} );
	</script>
	<!--light-box-->
	<script type="text/javascript" src="js/jquery.lightbox.js"></script>
	<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="screen">
	<script type="text/javascript">
		$( function () {
			$( '.gallery a' ).lightBox();
		} );
	</script>
</head>

<body>
	<div class="header">
		<div class="wrap">
			<div class="header-top">
				<div class="logo">
					<a href="index.html">Learning Managment System</a>
				</div>
				<div class="lofin-register">
					<span><a href="login.php">Login</a></span><span class="register"><a href="index.php">Register</a></span>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<div class="menu">
			<div class="wrap">
				<div class="top-nav">
					<ul class="nav">
						<li class="active"><a href="index.php">Home</a>
						</li>
						<li><a href="about.php">About</a>
						</li>
						<li><a href="gallery.php">Gallery</a>
						</li>
						<li><a href="contact.php">Contact</a>
						</li>
						<div class="clear"></div>
					</ul>
					<div class="search">
						<form>
							<input type="text" value="">
							<input type="submit" value="">
						</form>
					</div>
					<div class="clear"></div>
				</div>
			</div>
		</div>
	</div>
	