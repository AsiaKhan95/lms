<?php include("include/header.php"); ?>
<?php include("include/image-slider.php"); ?>
<div class="wrap">
	  <div class="main">
		<div class="section group">
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic.jpg" alt=""/>
						<div class="banner-box3">
							<span class="text20">Useful Info</span>
							<a href="#" class="link2"></a>
						</div>
						<p class="desc">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
						<div class="more">
						  <a href="#" class="button">Read More</a>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic1.jpg" alt=""/>
						<div class="banner-box3">
							<span class="text20">Our Community</span>
							<a href="#" class="link2"></a>
						</div>
						<p class="desc">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
						<div class="more">
						  <a href="#" class="button">Read More</a>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic2.jpg" alt=""/>
						<div class="banner-box3">
							<span class="text20">Private Tuition</span>
							<a href="#" class="link2"></a>
						</div>
						<p class="desc">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
						<div class="more">
						  <a href="#" class="button">Read More</a>
						</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<img src="images/pic3.jpg" alt=""/>
						<div class="banner-box3">
							<span class="text20">Basic Program</span>
							<a href="#" class="link2"></a>
						</div>
						<p class="desc">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
						<div class="more">
						  <a href="#" class="button">Read More</a>
						</div>
				</div>
				<div class="clear"></div>
			</div>
			<div class="bottom-grids">
				  <div class="bottom-grid1">
							<h3>POPULAR INFO</h3>
							<span>consectetur adipisicing elit, sed do eiusmod tempor</span>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
							<ul>
								<li><a href="#"><img src="images/marker1.png"> consectetur adipisicing elit</a></li>
								<li><a href="#"><img src="images/marker1.png"> sed do eiusmod tempor incididunt</a></li>
								<li><a href="#"><img src="images/marker1.png"> labore et dolore magna aliqua.</a></li>
								<li><a href="#"><img src="images/marker1.png"> sed do eiusmod tempor</a></li>
								<li><a href="#"><img src="images/marker1.png"> abore et dolore magna</a></li>
								<li><a href="#"><img src="images/marker1.png"> incididunt ut labore et dolore</a></li>
								<li><a href="#"><img src="images/marker1.png"> dolore magna aliqua</a></li>
								<li><a href="#"><img src="images/marker1.png"> adipisicing elit, sed do eiusmod</a></li>
								<li><a href="#"><img src="images/marker1.png"> adipisicing elit, sed do eiusmod</a></li>
								<div class="clear"> </div>
							 </ul><br>
									<a href="#" class="button">Read More</a>
					</div>
								<div class="bottom-grid2 bottom-mid">
									<h3>Our Staff</h3>
									<span>consectetur adipisicing elit, sed do eiusmod tempor</span>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. consectetur adipisicing elit, sed do eiusmod adipisicing elit, sed do eiusmod tempor incididunt adipisicing elit, sed do</p>
									<div class="gallery">
										<ul>
												<li><a href="images/t-pic4.jpg"><img src="images/pic4.jpg" alt=""></a></li>
												<li><a href="images/t-pic5.jpg"><img src="images/pic5.jpg" alt=""></a></li>
												<li><a href="images/t-pic6.jpg"><img src="images/pic6.jpg" alt=""></a></li>
												<li><a href="images/t-pic4.jpg"><img src="images/pic7.jpg" alt=""></a></li>
												<li><a href="images/t-pic5.jpg"><img src="images/pic8.jpg" alt=""></a></li>
												<li><a href="images/t-pic6.jpg"><img src="images/pic9.jpg" alt=""></a></li>
												<li><a href="images/t-pic4.jpg"><img src="images/pic10.jpg" alt=""></a></li>
												<li><a href="images/t-pic5.jpg"><img src="images/pic11.jpg" alt=""></a></li>
												<li><a href="images/t-pic6.jpg"><img src="images/pic12.jpg" alt=""></a></li>
											<div class="clear"> </div>
										</ul><br>
								    </div>									
										<a href="#" class="button">Read More</a>
								</div>
							    <div class="bottom-grid3 bottom-last">
									<h3>Latest INFO</h3>
									<span>consectetur adipisicing elit, sed do eiusmod tempor</span>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempo.</p>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt .</p>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt .</p>
									<br>
									<a href="#" class="button">Read More</a>
								</div>
								<div class="clear"> </div>
			</div>
	     </div>
	</div>
<?php include("include/footer.php"); ?>